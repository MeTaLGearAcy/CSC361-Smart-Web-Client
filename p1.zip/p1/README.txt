# SmartClient
This is a simple http get client that get http headers' information from indicated server.
Use python3 SmartClient.py <example.com> to run this program.
---
